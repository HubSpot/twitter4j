/**
 * example codes for list resources
 */
package twitter4j.examples.list;