package twitter4j.util;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class EngagementRequestObjectTest {


  @Test
  public void testJson(){

  }
}
