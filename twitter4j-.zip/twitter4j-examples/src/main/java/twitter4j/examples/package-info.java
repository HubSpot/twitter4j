/**
 * Twitter4J examples
 */
package twitter4j.examples;