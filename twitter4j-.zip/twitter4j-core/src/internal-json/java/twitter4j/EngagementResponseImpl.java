package twitter4j;

import twitter4j.conf.Configuration;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/*package*/ public class EngagementResponseImpl extends TwitterResponseImpl implements EngagementResponse, java.io.Serializable {

  Map<Long, Map<EngagementTypes, Integer>> perTweetMetricsOwned;
  Map<Long, Map<EngagementTypes, Integer>> perTweetMetricsUnowned;

  public EngagementResponseImpl(HttpResponse res, Configuration conf) throws TwitterException {
    super(res);
    JSONObject json = res.asJSONObject();
    init(json);
    if (conf.isJSONStoreEnabled()) {
      TwitterObjectFactory.clearThreadLocalMap();
      TwitterObjectFactory.registerJSONObject(this, json);
    }
  }

  public EngagementResponseImpl(JSONObject json) throws TwitterException {
    init(json);
  }

  private void init(JSONObject json) throws TwitterException {

    Map<Long, Map<EngagementTypes, Integer>> perTweetMetricsOwnedBuilder = new HashMap<>();
    try {
      JSONObject perTweetMetricsOwned = json.getJSONObject("perTweetMetricsOwned");
      Iterator perTweetMetricsOwnedKeys = perTweetMetricsOwned.keys();
      while (perTweetMetricsOwnedKeys.hasNext()) {
        String tweetName = (String) perTweetMetricsOwnedKeys.next();
        JSONObject tweet = perTweetMetricsOwned.getJSONObject((tweetName));
        Iterator tweetKeys = tweet.keys();
        Map<EngagementTypes, Integer> perTweetMap = new HashMap<>();
        while (tweetKeys.hasNext()) {
          String tweetKey = (String) tweetKeys.next();
          JSONObject rateLimitStatusJSON = perTweetMetricsOwned.getJSONObject(tweetKey);
          int total = rateLimitStatusJSON.getInt(tweetKey);

          perTweetMap.put(EngagementTypes.valueOf(tweetKey), total);
        }
        perTweetMetricsOwnedBuilder.put(Long.valueOf(tweetName), perTweetMap);
      }
    } catch (JSONException jsone) {
      throw new TwitterException(jsone);
    }
    perTweetMetricsOwned = Collections.unmodifiableMap(perTweetMetricsOwnedBuilder);
  }

  @Override
  public Map<Long, Map<EngagementTypes, Integer>> getPerTweetMetricsUnowned() {
    return null;
  }

  @Override
  public Map<Long, Map<EngagementTypes, Integer>> getperTweetMetricsOwned() {
    return null;
  }

  @Override
  public RateLimitStatus getRateLimitStatus() {
    return null;
  }

  @Override
  public int getAccessLevel() {
    return 0;
  }
}
