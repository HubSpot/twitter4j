/**
 * example code for the search API
 */
package twitter4j.examples.search;